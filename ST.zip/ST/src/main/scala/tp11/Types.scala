package tp11

import scala.collection.immutable.ListMap

sealed trait Term
case object EOF extends Term
case class Var(name : String) extends Term
case class Val(x : Var, t : Term) extends Term
case class App(t1: Term, t2: Term) extends Term
case class Rec(fields: ListMap[String, Term]) extends Term
//case class Abs(t1: Term, t2: Term) extends Term

/*case class App(t1: Term, t2: Term, t3: Term) extends Term*/
case class Abs(t1: Var, t2: Typ, t3: Term) extends Term

case object True extends Term
case object False extends Term
case object Zero extends Term

sealed trait Typ
case object Nat extends Typ
case object Bool extends Typ
case object Unit extends Typ
case class Fct(argType: Typ, returnType: Typ) extends Typ

case class Succ(t1: Term) extends Term
case class Pred(t1: Term) extends Term
case class IsZero(t1: Term) extends Term
case class Cond(t1: Term, t2: Term, t3: Term) extends Term

case class LetIn(x: Var, t1: Term, t2: Term) extends Term
case class Proj(t1: Term, lab: String) extends Term
case class Fix(t1: Term) extends Term
case class Malloc(t1: Term) extends Term
case class Bang(t1: Term) extends Term
case class Loc(adr: String) extends Term
//case class Rec(fields: Term) extends Term
case class Assign(t1: Term, t2: Term)
