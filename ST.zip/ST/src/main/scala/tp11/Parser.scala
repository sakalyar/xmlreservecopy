package tp11

import scala.collection.immutable.ListMap
import scala.util.parsing.combinator.JavaTokenParsers

/**
 * prog --> '\z'
 *   |  cmd ";;"
 * cmd --> seq
 *   |  val v '=' seq
 *   |  letrec f':' typ '=' t 
 * seq --> t (';' t)*
 * t --> open
 *   |  atom+ t
 * open --> fct
 *   |  if seq then seq else t
 *   |  succ t
 *   |  pred t
 *   |  iszero t
 *   |  let x = seq in t
 *   |  atom'.'label
 *   |  ref t
 *   |  '!'t
 *   |  atom := t
 * fct --> lambda x':' typ'.' seq
 * atom --> x
 *   |  '('seq')'
 *   |  true
 *   |  false
 *   |  0
 *   |  unit
 *   |  '{' fields? '}'
 * fields --> label '=' seq (',' fields)?
 * typ --> atomTyp ("->" atomTyp)*
 * atomTyp --> '('typ')'
 *   |  Bool
 *   |  Nat
 *   |  Unit
 *   |  '{' fieldsTyp? '}'
 *   |  Ref atomTyp
 * fieldsTyp --> label ':' typ (',' fieldsTyp)?
 */
class Parser extends JavaTokenParsers {
  protected override val whiteSpace = """(\s|#.*)+""".r
  override val ident = """[a-zA-Z][a-zA-Z0-9]*""".r
  def keywords = Set("val")
  
  def prog : Parser[Term] = eof | cmd<~";;"
  def eof = """\z""".r ^^ { _ => EOF}
  def cmd : Parser[Term] = ???
  def seq : Parser[Term] = ???
  def term : Parser[Term] = ???
  def open = ???
  def lambda = ???
  def cond = ???
  def succ = ???
  def pred = ???
  def isZero = ???
  def letIn = ???
  def proj = ???
  def malloc = ???
  def bang = ???
  def assign = ???
  def atom = ???
  def variable = ???
  def tFalse = ???
  def tTrue = ???
  def zero = ???
  def u = ???
  def record : Parser[Term] = ???
  def fields: Parser[ListMap[String, Term]] = ???
  def typ : Parser[Typ] = ???
  def atomTyp : Parser[Typ] = ???
  def bool = ???
  def nat = ???
  def unit = ???
  def recordTyp : Parser[Typ] = ???
  def fieldsTyp: Parser[ListMap[String, Typ]] = ???
  def refTyp = ???
}