package tp09

import scala.collection.immutable.ListMap
import TypeChecker._

class TypeChecker {
  /** Modélise un contexte de typage */
  private type Context = ListMap[Var, Typ]

  /** Retourne le type de "t" si "t" est typable, un message d'erreur sinon. */
  def checkType(t: Term): OptTyp = checkType(t, ListMap())

  private def checkType(t: Term, gamma: Context): OptTyp = t match {
    case Var(x) =>
      gamma.get(Var(x)) match {
        case Some(typ) => SomeTyp(typ)
        case None => NoTyp(s"Variable $x n'est pas dans le contexte")
      }
    case True => SomeTyp(Bool)
    case False => SomeTyp(Bool)
    case Zero => SomeTyp(Nat)
    case Succ(t1) => checkType(t1, gamma) match {
      case SomeTyp(Nat) => SomeTyp(Nat)
      case _ => NoTyp("Argument de succ doit etre de type Nat")
    }
  }
}

object TypeChecker {
  /**
   * Modélise un type optionnel, avec un message d'erreur quand le typage
   *  n'a pu être réalisé.
   */
  sealed abstract class OptTyp
  case class SomeTyp(typ: Typ) extends OptTyp
  case class NoTyp(msg: String) extends OptTyp
}