package tp09

import scala.util.parsing.combinator.JavaTokenParsers

import scala.collection.immutable.ListMap

/**
 * prog --> '\z'
 *   |  cmd ";;"
 * cmd --> seq
 *   |  val v '=' seq
 *   |  letrec f':' typ '=' t
 * seq --> t (';' t)*
 * t --> open
 *   |  atom+ t?
 * open --> fct
 *   |  if seq then seq else t
 *   |  succ t
 *   |  pred t
 *   |  iszero t
 *   |  let x = seq in t
 *   |  atom'.'label
 * fct --> lambda x':' typ'.' seq
 * atom --> x
 *   |  '('seq')'
 *   |  true
 *   |  false
 *   |  0
 *   |  unit
 *   |  '{' fields? '}'
 * fields --> label '=' seq (',' fields)?
 * typ --> atomTyp ("->" atomTyp)*
 * atomTyp --> '('typ')'
 *   |  Bool
 *   |  Nat
 *   |  Unit
 *   |  '{' fieldsTyp? '}'
 * fieldsTyp --> label ':' typ (',' fieldsTyp)?
 */
class Parser extends JavaTokenParsers {
  protected override val whiteSpace = """(\s|#.*)+""".r
  override val ident = """[a-zA-Z][a-zA-Z0-9]*""".r
  def keywords = Set("val")
  
  def prog : Parser[Term] = eof | cmd<~";;"
  def eof = """\z""".r ^^ { _ => EOF}

  def cmd: Parser[Term] = ???

  /*def seq: Parser[Term] = repsep(t, ";") ^^ {
    case terms => terms.reduceRight((t1, t2) => App(t1, t2))
  }

  // def t: Parser[Term] = open | term

  //def open: Parser[Term] = lambda | cond | succ | pred | isZero | letIn | proj

  /*def lambda: Parser[Term] = ("lambda" ~> ident) ~ (":" ~> typ) ~ ("." ~> seq) ^^ {
    case x ~ typ ~ t => Abs(Var(x), term: Term, t)
  }*/

  def cond: Parser[Term] = ("if" ~> seq) ~ ("then" ~> seq) ~ ("else" ~> t) ^^ {
    case t1 ~ t2 ~ t3 => Cond(t1, t2, t3)
  }

  def succ: Parser[Term] = "succ" ~> t ^^ { t => Succ(t) }

  def pred: Parser[Term] = "pred" ~> t ^^ { t => Pred(t) }

  def isZero: Parser[Term] = "iszero" ~> t ^^ { t => IsZero(t) }*/

  /*def letIn: Parser[Term] = ("let" ~> ident) ~ ("=" ~> seq) ~ ("in" ~> t) ^^ {
    case x ~ t1 ~ t2 => App(Abs(Var(x), t1), t2)
  }*/

  /*def proj: Parser[Term] = atom ~ ("." ~> ident) ^^ {
    case t ~ lab => Proj(t, lab)
  }*/

  def seq : Parser[Term] = ???
  def term : Parser[Term] = ???
  def atom = ???
  def variable = ???
  def tFalse = ???
  def tTrue = ???
  def zero = ???
  def u = ???
  def record : Parser[Term] = ???
  def fields: Parser[ListMap[String, Term]] = ???
  def typ : Parser[Typ] = ???
  def atomTyp = ???
  def bool = ???
  def nat = ???
  def unit = ???
  def recordTyp : Parser[Typ] = ???
  def fieldsTyp: Parser[ListMap[String, Typ]] = ???
}