package tp10

import scala.collection.immutable.ListMap

import org.junit.runner.RunWith
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.junit.JUnitRunner
import org.scalatest.matchers.must.Matchers
import org.scalatest.matchers.should.Matchers._
import org.scalatest.PrivateMethodTester
import TypeChecker._

@RunWith(classOf[JUnitRunner])
class TypeCheckerTest extends AnyFunSuite with Matchers with PrivateMethodTester {
  val typeChecker = new TypeChecker
  val privateCheckType = PrivateMethod[OptTyp](Symbol("checkType"))
  import typeChecker._

  val x = Var("x")
  val n = Var("n")
  val f = Var("f")
  val lab1 = "lab1"
  val lab2 = "lab2"
  val lab3 = "lab3"
  val lab = "lab"
  val id = Abs(x, Bool, x)
  
  test("|- true : Bool") {
    assert(checkType(True) === SomeTyp(Bool))
  }
  test("|- false : Bool") {
    assert(checkType(False) === SomeTyp(Bool))
  }
  test("|- 0 : Nat") {
    assert(checkType(Zero) === SomeTyp(Nat))
  }
  /*test("|- unit : Unit") {
    assert(checkType(U) === SomeTyp(Unit))
  }*/
  
  
  test("|- 1 : Nat") {
    assert(checkType(Succ(Zero)) === SomeTyp(Nat))
  }
  test("|- succ true : NoTyp(...)") {
    checkType(Succ(True)) should matchPattern {case NoTyp(_) => }
  }

  
  test("|- pred 0 : Nat") {
    assert(checkType(Pred(Zero)) === SomeTyp(Nat))
  }
  test("|- pred true : NoTyp(...)") {
    checkType(Pred(True)) should matchPattern {case NoTyp(_) => }
  }
  
  
  test("|- iszero 0 : Bool") {
    assert(checkType(IsZero(Zero)) === SomeTyp(Bool))
  }
  test("|- iszero true : NoTyp(...)") {
    checkType(IsZero(True)) should matchPattern {case NoTyp(_) => }
  }
  
  
  test("|- val n = 1 : Nat") {
    assert(checkType(Val(n, Succ(Zero))) === SomeTyp(Nat))
  }
  
  
  test("(x->Bool) |- x : Bool") {
    val gamma = ListMap(x -> Bool)
    assert((typeChecker invokePrivate privateCheckType(x, gamma))
        === SomeTyp(Bool))
  }
  
  
  test("|- if true then 0 else 1 : Nat") {
    val cond = Cond(True, Zero, Succ(Zero))
    assert(checkType(cond) === SomeTyp(Nat))
  }
  test("|- if true then 0 else false : NoTyp(...)") {
    val cond = Cond(True, Zero, False)
    checkType(cond) should matchPattern {case NoTyp(_) => }
  }
  test("|- if true then 0 else (succ true) : NoTyp(...)") {
    val cond = Cond(True, Zero, Succ(True))
    checkType(cond) should matchPattern {case NoTyp(_) => }
  }
  test("|- if true then (succ true) else 0 : NoTyp(...)") {
    val cond = Cond(True, Succ(True), Zero)
    checkType(cond) should matchPattern {case NoTyp(_) => }
  }
  test("|- if 0 then true else false : NoTyp(...)") {
    val cond = Cond(Zero, True, False)
    checkType(cond) should matchPattern {case NoTyp(_) => }
  }
  test("|- if (succ true) then true else false : NoTyp(...)") {
    val cond = Cond(Succ(True), True, False)
    checkType(cond) should matchPattern {case NoTyp(_) => }
  }
  
  
  test("|- let x = 0 in (lambda x : Nat. iszero x) x : Bool") {
    val let = LetIn(x, Zero, App(Abs(x, Nat, IsZero(x)), x))
    assert(checkType(let) === SomeTyp(Bool))
  }
  test("|- let x = succ true in x : NoTyp(...)") {
    val let = LetIn(x, Succ(True), x)
    checkType(let) should matchPattern {case NoTyp(_) => }
  }
  
  
  test("|- fix(lambda x : Nat. succ x) : Nat") {
    val fix = Fix(Abs(x, Nat, Succ(x)))
    assert(checkType(fix) === SomeTyp(Nat))
  }
  test("|- fix(lambda x : Nat. iszero x) : NoTyp(...)") {
    val fix = Fix(Abs(x, Nat, IsZero(x)))
    checkType(fix) should matchPattern {case NoTyp(_) => }
  }  
  test("|- fix(pred false) : NoTyp(...)") {
    val fix = Fix(Pred(False))
    checkType(fix) should matchPattern {case NoTyp(_) => }
  }  
  
  
  test("|- lambda x : Bool. x) : Bool -> Bool") {
    val abs = Abs(x, Bool, x)
    assert(checkType(abs) === SomeTyp(Fct(Bool,Bool)))
  }
  test("(f -> (Bool -> Nat)) |- lambda x : Bool. f x : Bool -> Nat") {
    val abs = Abs(x, Bool, App(f, x))
    val gamma = ListMap(f -> Fct(Bool, Nat))
    assert((typeChecker invokePrivate privateCheckType(abs, gamma))
        === SomeTyp(Fct(Bool, Nat)))
  }
  test("|- lambda x : Bool. succ x : NoTyp(...)") {
    val abs = Abs(x, Bool, Succ(x))
    checkType(abs) should matchPattern {case NoTyp(_) => }
  }
  
  
  test("|- (lambda n : Nat. succ n) 0 : SomeTyp(Nat)") {
    val app = App(Abs(n, Nat, Succ(n)), Zero)
    assert(checkType(app) === SomeTyp(Nat))
  }
  test("|- (lambda n : Nat. succ n) true : NoTyp(...)") {
    val app = App(Abs(n, Nat, Succ(n)), True)
    checkType(app) should matchPattern {case NoTyp(_) => }
  }
  test("|- (lambda n : Nat. succ n) (succ true) : NoTyp(...)") {
    val app = App(Abs(n, Nat, Succ(n)), Succ(True))
    checkType(app) should matchPattern {case NoTyp(_) => }
  }
  test("|- 0 true : NoTyp(...)") {
    val app = App(Zero, True)
    checkType(app) should matchPattern {case NoTyp(_) => }
  }
  test("|- (succ true) true : NoTyp(...)") {
    val app = App(Succ(True), True)
    checkType(app) should matchPattern {case NoTyp(_) => }
  }
  
  
  /*test("|- {lab1 = 0, lab2 = true, lab3 = id}"
      + " : {lab1 : Nat, lab2 : Bool, lab3 : Bool -> Bool}") {
    val rec = Rec(ListMap(lab1 -> Zero, lab2 -> True, lab3 -> id))
    assert(checkType(rec) === SomeTyp(
        Record(ListMap(lab1 -> Nat, lab2 -> Bool, lab3 -> Fct(Bool, Bool)))))
  }
  test("|- {lab1 = 0, lab2 = succ true, lab3 = id} : NoTyp(...)") {
    val rec = Rec(ListMap(lab1 -> Zero, lab2 -> Succ(True), lab3 -> id))
    checkType(rec) should matchPattern {case NoTyp(_) => }
  }


  test("|- {lab1 = 0, lab2 = true, lab3 = id}.lab2 : Bool") {
    val proj = Proj(
        Rec(ListMap(lab1 -> Zero, lab2 -> True, lab3 -> id))
        , lab2)
    assert(checkType(proj) === SomeTyp(Bool))
  }
  test("|- {lab1 = 0, lab2 = true, lab3 = id}.lab : NoTyp(...)") {
    val proj = Proj(Rec(ListMap(lab1 -> Zero, lab2 -> True, lab3 -> id)), lab)
    checkType(proj) should matchPattern {case NoTyp(_) => }
  }
  test("|- true.lab : NoTyp(...)") {
    val proj = Proj(True, lab)
    checkType(proj) should matchPattern {case NoTyp(_) => }
  }
  test("|- pred true.lab : NoTyp(...)") {
    val proj = Proj(Pred(True), lab)
    checkType(proj) should matchPattern {case NoTyp(_) => }
  }
  

  test(" |- ref 0 : Ref Nat") {
    val ref = Malloc(Zero)
    assert(checkType(ref) === SomeTyp(Ref(Nat)))
  }
  test("|- ref succ true : NoTyp(...)") {
    val ref = Malloc(Succ(True))
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }


  test(" |- ! ref 0 : Nat") {
    val ref = Bang(Malloc(Zero))
    assert(checkType(ref) === SomeTyp(Nat))
  }
  import Util.memory
  test(" |- ! Loc(1) | <0->(0, Nat), 1->(id, Bool -> Bool), 2->(true, Bool)>"
      + ": Bool -> Bool") {
    val ref = Bang(Loc(1))
    memory.clear()
    memory += ((Zero, Nat))
    memory += ((id, Fct(Bool, Bool)))
    memory += ((True, Bool))
    assert(checkType(ref) === SomeTyp(Fct(Bool, Bool)))
  }
  test("|- ! true : NoTyp(...)") {
    val ref = Bang(True)
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }
  test("|- ! succ true : NoTyp(...)") {
    val ref = Bang(Succ(True))
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }


  test(" |- ref 0 := 1 : Unit") {
    val ref = Assign(Malloc(Zero), Succ(Zero))
    assert(checkType(ref) === SomeTyp(Unit))
  }
  test(" |- ref 0 := true : NoTyp(...)") {
    val ref = Assign(Malloc(Zero), True)
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }
  test(" |- ref 0 := pred true : NoTyp(...)") {
    val ref = Assign(Malloc(Zero), Pred(True))
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }
  test(" |- 0 := 1 : NoTyp(...)") {
    val ref = Assign(Zero, Succ(Zero))
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }
  test(" |- iszero true := 1 : NoTyp(...)") {
    val ref = Assign(IsZero(True), Succ(Zero))
    checkType(ref) should matchPattern {case NoTyp(_) => }
  }*/
}