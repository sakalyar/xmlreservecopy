package tp04
/*
trait InfinitePlayground extends GameEnv {
  lazy val playground: Playground = (pos: Pos) => true
}
*/